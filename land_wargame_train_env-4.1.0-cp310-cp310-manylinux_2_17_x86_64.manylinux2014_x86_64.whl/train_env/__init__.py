from train_env.env.train_env import TrainEnv

__version__ = "4.1.0"

print(f'SDK version: {__version__}')
